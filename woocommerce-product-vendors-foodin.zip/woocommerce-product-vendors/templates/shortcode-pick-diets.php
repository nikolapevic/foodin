<?php
/**
 * Foodin Diet Template
 *
 * @version 1.0.0.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<style>
	* {
		box-sizing: border-box;
	}

	body {
		background-color: #f1f1f1;
	}

	#regForm {
		background-color: #ffffff;
		margin: 100px auto;
		font-family: Raleway;
		padding: 40px;
		width: 70%;
		min-width: 300px;
	}

	input {
		padding: 10px;
		width: 100%;
		font-size: 17px;
		font-family: Raleway;
		border: 1px solid #aaaaaa;
	}

	/* Mark input boxes that gets an error on validation: */
	input.invalid {
		background-color: #ffdddd;
	}

	/* Hide all steps by default: */
	.tab {
		display: none;
	}

	#prevBtn {
		background-color: #bbbbbb;
	}

	/* Make circles that indicate the steps of the form: */
	.step {
		height: 10px;
		width: 10px;
		margin: 0 2px;
		background-color: #bbbbbb;
		border: none;  
		border-radius: 50%;
		display: inline-block;
		opacity: 0.5;
	}

	.step.active {
		opacity: 1;
	}

	/* Mark the steps that are finished and valid: */
	.step.finish {
		background-color: #91e094;
	}
</style>

<?php


$user_id = get_current_user_id();
$user = wp_get_current_user();


function foodin_form_update($name, $user_id){
	if($_POST[$name]){
		update_user_meta( $user_id, $name, $_POST[$name] );
	}
}

foodin_form_update('gender', $user_id);
foodin_form_update('goal', $user_id);
foodin_form_update('height', $user_id);
foodin_form_update('weight', $user_id);
if($_POST['weight']){
	update_user_meta( $user_id, 'starting_weight', $_POST['weight'] );
	update_calculate_bmr($_POST['gender'], $_POST['weight'], $_POST['height'], $_POST['age'], $_POST['activity'], $user_id);
}
foodin_form_update('desired_weight', $user_id);
foodin_form_update('age', $user_id);
foodin_form_update('body_type', $user_id);
foodin_form_update('typical_day', $user_id);
foodin_form_update('habits', $user_id);//Checkbox
foodin_form_update('activity', $user_id);

foodin_form_update('sleep', $user_id);
foodin_form_update('drink', $user_id);
foodin_form_update('motivation', $user_id);
foodin_form_update('behavior', $user_id);
foodin_form_update('vegetables', $user_id);//Checkbox
foodin_form_update('products', $user_id);//Checkbox
foodin_form_update('meat', $user_id);//Checkbox
foodin_form_update('cooking', $user_id);

$genders = ['Male','Female'];
$goal = ['Gain Weight','Lose Weight', 'Be healthy'];
$body_type = ['Ectomorph','Mesomorph','Endomorph'];
$typical_day = ['At the office','Daily Long Walks','Physical Work','Mostly at Home'];
$habits = ['I eat late at night','I dont sleep enough','I like sweets','I love soft drinks', 'I consume a lot of salt', 'None of the above'];
$activity = ['Barely Active', '1-2 times a week', '3-5 times', '5-7 times', 'More than once a day'];
$sleep = ['5 hours', '5-6 hours', '7-8 hours', 'more than 8 hours'];
$drink = ['Coffee or tea', 'Less than 2 glasses - 0,5l','2-6 glasses 0,5-1,5 l','More than 6 glasses'];
$motivation = ['I need motivation', 'I can motivate myself'];
$behavior = ['Yes','No'];
$vegetables = ['Broccoli', 'Sweet potato', 'Mushrooms', 'Tomato', 'Peas', 'Spinach', 'Zucchini', 'Pepper'];
$products = ['Avocado', 'Eggs', 'Yoghurt', 'Cottage cheese', 'Tofu', 'Olives', 'Peanut butter', 'Nuts, Mozzarella', 'Milk'];
$meat = ['Turkey','Fish','Beef','Chicken','Pork','None'];
$cooking = ['< 30','30- 60 min','More than one hour'];


function checkbox_options($array, $name){
	foreach($array as $key => $value){
		echo '<label class="bundled_product_optional_checkbox"><input type="checkbox" class="ddwc-left bundled_product_checkbox" value="'.$value.'" name="'.$name.'[]"><span class="checkmark"></span>'.$value.'</label><br>';
	}
}

function radio_options($array, $name){
	foreach($array as $key => $value){
		echo '<input type="radio" oninput="this.className" id="'.$value.'" name="'.$name.'" value="'.$value.'">';
		echo '<label for="'.$value.'">'.$value.'</label><br>';
	}
}

$dw_meta = esc_attr(get_the_author_meta( 'desired_weight', $user->ID ));

if (! $dw_meta){
?>




<form id="regForm" method="post" action="">
	<h1>Register:</h1>
	<!-- One "tab" for each step in the form: -->
	<div class="tab">Gender:<br>
		<?php radio_options($genders, 'gender'); ?>
	</div>
	<div class="tab">Goals:<br>
		<?php radio_options($goal, 'goal'); ?>
	</div>
	<div class="tab">Height and Weight:
		<select name="height">
			<?php
				for($i = 130; $i < 230; $i++){
					echo '<option value="'.$i.'">'. $i .' cm'.'</options>';
				}
			?>
		</select>
		<select name="weight">
			<?php
				for($i = 30; $i < 200; $i++){
					echo '<option value="'.$i.'">'. $i .' kg'.'</options>';
				}
			?>
		</select>
	</div>
	<div id="desiredWeight" class="tab">Desired Weight:<br>
		<input type="text" name="desired_weight"><h4>kg</h4>
	</div>
	<div id="age" class="tab">Age:<br>
		<input type="text" name="age">
	</div>
	<div class="tab">Body Type:
		<?php radio_options($body_type, 'body_type'); ?>
	</div>
	<div class="tab">Habits:
		<?php checkbox_options($habits, 'habits');?>
	</div>
	<div class="tab">Typical Day:
		<?php radio_options($typical_day, 'typical_day'); ?>
	</div>
	<div class="tab">Activity:
		<?php radio_options($activity, 'activity'); ?>
	</div>
	<div class="tab">Sleep:
		<?php radio_options($sleep, 'sleep'); ?>
	</div>
	<div class="tab">Drink:
		<?php radio_options($drink, 'drink'); ?>
	</div>
	<div class="tab">Motivation:
		<?php radio_options($motivation, 'motivation'); ?>
	</div>
	<div class="tab">Behavior:
		<?php radio_options($behavior, 'behavior'); ?>
	</div>
	<div class="tab">Vegetables:
		<?php checkbox_options($vegetables, 'vegetables');?>
	</div>
	<div class="tab">Products:
		<?php checkbox_options($products, 'products');?>
	</div>
	<div class="tab">Meat:
		<?php checkbox_options($meat, 'meat');?>
	</div>
	<div class="tab">Cooking:
		<?php radio_options($cooking, 'cooking');?>
	</div>
	<div class="tab">
		<h2>
			Thank you
		</h2>
	</div>
	<div id="error-message"></div>
	<div style="overflow:auto;">
		<div style="float:right;">
			<button class="btn button" type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
			<button class="btn button" type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
			<button class="btn button" type="submit" id="submitBtn">Submit</button>
		</div>
	</div>
	<!-- Circles which indicates the steps of the form: -->
	<div style="text-align:center;margin-top:40px;">
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
		<span class="step"></span>
	</div>
</form>
<script>
	var currentTab = 0; // Current tab is set to be the first tab (0)
	showTab(currentTab); // Display the current tab

	function showTab(n) {
		// This function will display the specified tab of the form...
		var x = document.getElementsByClassName("tab");
		x[n].style.display = "block";
		//... and fix the Previous/Next buttons:
		if (n == 0) {
			document.getElementById("prevBtn").style.display = "none";
		} else {
			document.getElementById("prevBtn").style.display = "inline";
		}
		if (n == (x.length - 1)) {
			document.getElementById("nextBtn").style.display = "none";
			document.getElementById("submitBtn").style.display = "inline";
		} else {
			document.getElementById("nextBtn").innerHTML = "Next";
			document.getElementById("nextBtn").style.display = "inline";
			document.getElementById("submitBtn").style.display = "none";
		}
		//... and run a function that will display the correct step indicator:
		fixStepIndicator(n)
	}

	function nextPrev(n) {
		// This function will figure out which tab to display
		var x = document.getElementsByClassName("tab");
		// Exit the function if any field in the current tab is invalid:
		if (n == 1 && !validateForm()) return false;
		// Hide the current tab:
		x[currentTab].style.display = "none";
		// Increase or decrease the current tab by 1:
		currentTab = currentTab + n;
		// Otherwise, display the correct tab:
		showTab(currentTab);
	}

	function validateForm() {
		// This function deals with validation of the form fields
		var x, y, i, valid = true;
		x = document.getElementsByClassName("tab");
		y = x[currentTab].getElementsByTagName("input");
		// A loop that checks every input field in the current tab:
		var unchecked = 0;
		for (i = 0; i < y.length; i++) {
			if (y[i].checked == false && (y[i].type =='radio' || y[i].type =='checkbox')){
				unchecked++;
			}
			// If a field is empty...
			if (y[i].value == "") {
				// add an "invalid" class to the field:
				y[i].className += " invalid";
				// and set the current valid status to false
				valid = false;
			}

		}

		var error = document.getElementById("error-message");
		if (y[0]){
			if (unchecked == y.length){
				valid = false;
				error.innerHTML = '<ul class="woocommerce-error">You have to pick one option</ul></ul>';
			}
		}
		// If the valid status is true, mark the step as finished and valid:
		if (valid) {
			document.getElementsByClassName("step")[currentTab].className += " finish";
			error.innerHTML = "";
		}
		return valid; // return the valid status
	}

	function fixStepIndicator(n) {
		// This function removes the "active" class of all steps...
		var i, x = document.getElementsByClassName("step");
		for (i = 0; i < x.length; i++) {
			x[i].className = x[i].className.replace(" active", "");
		}
	}
</script>

<?php



			   } else {

	echo 'Your diet isnt assigned pick one';
	
?>

<form method="post" action="">
	<input type="submit" name="assigned_diet" value="8929" />
	<input type="submit" name="assigned_diet" value="13867" />
	<input type="submit" name="assigned_diet" value="13868" />
</form>

<?php
}


?>