<?php
/**
 * Vendor List Template
 *
 * @version 2.0.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<?php


//Split values into array
$matches = preg_split('/\,/', $atts['ids']);

$client = wp_get_current_user();
$client_id = $client->ID;
$needed_kcal = get_user_meta($client_id, 'amr', true);
$needed_fat = get_user_meta($client_id, 'needed_fat', true);
$needed_protein = get_user_meta($client_id, 'needed_protein', true);
$needed_fiber = get_user_meta($client_id, 'needed_fiber', true);
$needed_carbs = get_user_meta($client_id, 'needed_carbs', true);

$bundledItems = [];
$meals = '';
$preview = '';
$day_kcal = 0;
$day_proteins = 0;
$day_carbs = 0;
$day_fats = 0;
$day_fiber = 0;
foreach($matches as $key => $match){
    $results='';
    $output = '';
    $test = '';
    
    // Result of one product bundle
    $results = WC_PB_DB::query_bundled_items( array(
        'return'    => 'id=>product_id',
        'bundle_id' => $match,
    ) );
    
    //Push bundle ids in a collective bundle array
    array_push ($bundledItems, $results);
    
    //Assemble Meal element
    $product = wc_get_product( $match );
    $product_link = get_permalink($match);
    $price = $product->get_price_html();
    $servings = number_format(get_post_meta($match, 'servings', true));
    $product_description = strip_tags(do_shortcode($product->get_description()), '<ol><li>');
    if (! $product_description){
        $product_description = recipe_description($match);
    } else {
        $product_description = '<h3>Description</h3>' . $product_description;
    }
    if (empty($servings)){
        $servings = 1;
    }
    
    $bundleproduct = null;
    
    $numItems = count($results);
    $i = 0;
    $meal_kcal = 0;
    $meal_proteins = 0;
    $meal_carbs = 0;
    $meal_fats = 0;
    $meal_fiber = 0;
    
    // List bundle products associated to that product_id = $match
    foreach($results as $key => $id){
		$cats = array();
        $title =  WC_PB_DB::get_bundled_item_meta( $key, 'title' );
        $quantity = WC_PB_DB::get_bundled_item_meta( $key, 'quantity_min' );
        $override = WC_PB_DB::get_bundled_item_meta($key, 'override_description');
        $description = number_format(WC_PB_DB::get_bundled_item_meta($key, 'description'));

        $bproduct = wc_get_product( $id );
        $bpname = $bproduct->get_name();
        if ($title){
            $bpname = $title;
        }
		
		$terms = wp_get_post_terms( $id, 'product_cat' );
		foreach ( $terms as $term ) {
			array_push($cats,$term->slug);
		}
		
        $mweight = $bproduct->get_weight() * 1000;
        $bprice = $bproduct->get_price_html();
        
        $weight = $mweight;
		
		$b_id = $id;

        $calories = number_format(nutritional_info($override,$description,$weight,get_post_meta( $id, 'calories', true ),$servings),1);
        $proteins = number_format(nutritional_info($override,$description,$weight,get_post_meta( $id, 'proteins', true ),$servings),1);
        $carbs = number_format(nutritional_info($override,$description,$weight,get_post_meta( $id, 'carbs', true ),$servings),1);
        $fats = number_format(nutritional_info($override,$description,$weight,get_post_meta( $id, 'fats', true ),$servings),1);
        $fiber = number_format(nutritional_info($override,$description,$weight,get_post_meta( $id, 'fiber', true ),$servings),1);

        $meal_kcal += $calories;
        $meal_proteins += $proteins;
        $meal_carbs += $carbs;
        $meal_fats += $fats;
        $meal_fiber += $fiber;
		
		 $varoutput = '';
        $variations = $bproduct->get_children();
        $brand_name = '';
        $n = 0;
        if($variations){
            foreach($variations as $k => $v){
                $n++;
                $vproduct = wc_get_product($v);
                $vname = $vproduct->get_name();
                $vprice = $vproduct->get_price_html();
                $vweight = $vproduct->get_weight() * 1000;
                
                $picked_shop = 'Any Shop';
                if($_COOKIE['shop']){
                    $picked_shop = $_COOKIE['shop'];
                }

                $shop = $vproduct->get_attribute('shop');
                $brand = $vproduct->get_attribute('brand');
                $default = $bproduct->get_default_attributes();
                $default_brand = $default['brand'];
                if ($shop == $picked_shop){
                    if($brand == $default_brand){
                        $brand_name = $default_brand;
                        $id = $v;
                        $bprice = $vprice;
                        $weight = $vweight;
                    } elseif ($n == 1) {
                        $brand_name = $brand;
                        $id = $v;
                        $bprice = $vprice;
                        $weight = $vweight;
                    }
                }
            }
        }

        if ($description){
            $need = $description . 'g';
			if(in_array('drinks',$cats)||in_array('vinegar',$cats)||in_array('sauces',$cats)||in_array('oil',$cats)||in_array('milk',$cats)){
				$need = $description . 'ml';
			}
			$need = convert_units($b_id,$description,$weight,$need);
            if($weight > 0){
                if ($description < $weight){
                    $quantity = 1;
                } else {
                    $quantity = round($description/$weight,1);
                    if ($quantity > 1.2 && $quantity < 1.5){
                        $quantity = 2;
                    } else {
                        $quantity = round($quantity,0);
                    }
                }
            }
        } elseif (! $description){
            $need = $quantity;
            if($mweight > 0){
                if($quantity * $mweight < $weight){
                    $quantity = 1;
                } else {
                    $quantity = round($quantity*$mweight/$weight,0);
                }
            }
        }

        if($weight < 1000){
            $title_weight = $weight;
            $unit = 'g';
			if(in_array('drinks',$cats)||in_array('vinegar',$cats)||in_array('sauces',$cats)||in_array('oil',$cats)||in_array('milk',$cats)){
				$unit = 'ml';
			}
        } else {
            $title_weight = $weight/1000;
            $unit = 'kg';
				if(in_array('drinks',$cats)||in_array('vinegar',$cats)||in_array('sauces',$cats)||in_array('oil',$cats)||in_array('milk',$cats)){
				$unit = 'l';
			}
        }
        
        $add_to_cart = '<a href="?add-to-cart='.$id.'" data-quantity="'.$quantity.'" class="btn btn-secondary btn-sm button add_to_cart_button ajax_add_to_cart" data-product_id="'.$id.'" data-product_sku="" aria-label="Read more about “'.$bpname.'”" rel="nofollow"><i class="mdi mdi-cart-outline"></i> Add</a>';
        if ($bproduct->get_image_id()){
            $image = '<img class="bundle-pic" src="' . groci_resize( wp_get_attachment_url($bproduct->get_image_id()), 300, 300, true, true, true ) . '">';
        } else {
            $image = '<img class="bundle-pic" src="' .  wc_placeholder_img_src(). '">';
        }
        
        $bundleproduct .= '<div class="bundle-product">';
        $bundleproduct .= $image;
        $bundleproduct .= '<div class="bundle-product-description">';
        $bundleproduct .= '<div class="product-body">';
        $bundleproduct .= '<h5>' . $need . ' ' . $bpname . '</h5>';
        $bundleproduct .= 'Add '. $quantity . ' x ' . $title_weight . $unit . ' ' . $brand_name;
        // $bundleproduct .= '<p>'.$calories .' '. $proteins .' '. $carbs .' '. $fats .' '. $fiber . '</p>';
        $bundleproduct .= '<p class="offer-price mb-0">' . $bprice . '</p>';
        $bundleproduct .= '</div>';
        $bundleproduct .= '<div class="product-footer">' . $add_to_cart . '</div>';
        $bundleproduct .= '</div>';
        $bundleproduct .= '</div>';
    }

    $type = $product->get_type();
    if($type != 'bundle'){
        $meal_kcal = get_post_meta( $match, 'calories', true);
        if(!$meal_kcal){$meal_kcal = 0;}
        $meal_proteins = get_post_meta( $match, 'proteins', true);
        $meal_carbs = get_post_meta( $match, 'carbs', true);
        $meal_fats = get_post_meta( $match, 'fats', true);
        $meal_fiber = get_post_meta( $match, 'fiber', true);
    }
    
    $day_kcal += $meal_kcal;
    $day_proteins += $meal_proteins;
    $day_carbs += $meal_carbs;
    $day_fats += $meal_fats;
    $day_fiber += $meal_fiber;
	global $plan_subscription;
    $preview .= '<div class="meal-preview" id="'.$match.'">';
	if((is_super_admin()||active_subscription($plan_subscription,$client_id)) && strpos($_SERVER['REQUEST_URI'],'schedule')){
		$preview .= '<div class="add-to-list">'.add_meal_icon().'</div>';
	}
	
	$preview .= '<div class="meal-prev-wrapper" onclick="disappear(this.parentElement)">';
    if ($product->get_image_id()){
        $preview .= '<img class="plan_pic" loading="lazy" src="' . groci_resize( wp_get_attachment_url($product->get_image_id()), 640, 640, true, true, true ) . '">';
    } else {
        $preview .= '<img class="plan_pic" loading="lazy" src="' . wc_placeholder_img_src() . '">';
    }
    $preview .= '<div class="meal-preview-info">';
    $preview .= '<h4>' . $product->get_name() . '</h4>';
	$duration = get_post_meta($match,'duration',true);
	$servings = get_post_meta($match,'servings',true);
	if($duration){
		$preview .= '<div class="inline"><ion-icon name="time-outline"></ion-icon> ' . $duration . '</div>';
	}
    if($servings){
		$preview .= '<div class="inline"><ion-icon name="restaurant"></ion-icon> ' . $servings . '</div>';
	}
    $preview .= '</div>';
	$preview .= '</div>';
	
	
    $preview .= '</div>';
    $output .= '<div class="white-container disappear meal-'.$match.'">';
    $output .= '<h3>' . $product->get_name() . '</h3>';
    $output .= '<div class="bundle-product-wrapper">';
    
    if($type != 'bundle'){
        $output .= '<div class="diet-description">';
        $output .= $product_description;
        $output .= '</div>';
    } else {
		$output .= '<div class="diet-groceries-wrapper">';
        $output .= '<div class="ing-header"><h3>Ingredients</h3>' . print_servings($match, 'Ingredients') . '</div>';
        $output .= '<div class="diet-groceries">';
        $output .= $bundleproduct;
        $output .= '</div>';
		$output .= '</div>';
        $output .= '<div class="diet-description">';
		$output .= '<h3>Cooking instructions</h3>' . print_servings($match, 'Instructions');
        $output .= '<div class="steps-container">';
        $output .= $product_description;
		$output .= '</div>';
        $output .= '</div>';
    }
    $output .= '</div>';
    $output .= '<h3>Nutritional info</h3><p class="print-servings text-left">Nutritional values per 1 serving</p><div class="nutrition">';
    $output .= '<div class="macro kcal" data-percent="'.percentage($meal_kcal, $needed_kcal).'"><p>kcal</p><h4>'.$meal_kcal.'</h4></div>';
    $output .= '<div class="macro protein" data-percent="'.percentage($meal_proteins, $needed_protein).'"><p>protein</p><h4>'.$meal_proteins.' g</h4></div>';
    $output .= '<div class="macro carbs" data-percent="'.percentage($meal_carbs, $needed_carbs).'"><p>carbs</p><h4>'.$meal_carbs.' g</h4></div>';
    $output .= '<div class="macro fats" data-percent="'.percentage($meal_fats, $needed_fat).'"><p>fats</p><h4>'.$meal_fats.' g</h4></div>';
    $output .= '<div class="macro fiber" data-percent="'.percentage($meal_fiber, $needed_fiber).'"><p>fiber</p><h4>'.$meal_fiber.' g</h4></div>';
    $output .= '</div>';
    $output .= '</div>';
    
    $meals .= $output;
}


$container = '<div id="'.$atts['day_name'].'" class="meal-container">';
$container .= '<div class="meal-header">';
$container .= '<h3 class="inline float-left">' . $atts['day_name'] . '</h3>';
/*$container .= '<div class="inline float-right day-nutrition">';
$container .= '<div class="macro"><p>kc</p><h4>'.$day_kcal.'</h4></div>';
$container .= '<div class="macro"><p>p</p><h4>'.$day_proteins.'</h4></div>';
$container .= '<div class="macro"><p>c</p><h4>'.$day_carbs.'</h4></div>';
$container .= '<div class="macro"><p>fat</p><h4>'.$day_fats.'</h4></div>';
$container .= '<div class="macro"><p>f</p><h4>'.$day_fiber.'</h4></div>';
$container .= '</div>';*/
$container .= '</div>';
$container .= '<div class="preview-wrapper">';
if(count($matches)>3){
	$container .= '<div class="scrollbtn"><ion-icon class="nav__icon" name="arrow-forward-outline"></ion-icon></div>';
}
$container .= '<div class="preview-container">' . $preview . '</div>';
$container .= '</div>';
$container .= $meals;
$container .= '</div>';


echo $container;

