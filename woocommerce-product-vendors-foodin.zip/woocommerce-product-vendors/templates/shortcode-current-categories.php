<?php
/**
 * Vendor List Template
 *
 * @version 2.0.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
    <?php
    $user_ip = getenv('REMOTE_ADDR');
    $geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
    $country = $geo["geoplugin_countryName"];
    $region = $geo["geoplugin_regionName"];
    
    global $wp_query;
        $term = $wp_query->queried_object;

        $args_cat = array(
            'number'     => "",
            'orderby'    => "menu_order",
            'order'      => 'ASC',
            'hide_empty' => true,
            'parent'     => '',
            'include'    => $ids
        );


    $product_categories = get_terms( 'product_cat', $args_cat );

    $count = count($product_categories);
    
    global $post;
    $post_slug = $post->post_name;
    $grocery_cats = null;
	$recipe_cats = null;
	$plan_cats = null;
    $cat_grid = null;

    foreach ( $product_categories as $product_category ) {
        $cat_slug = $product_category->slug;
        $cat_id = $product_category->term_id;
        $parent_id = $product_category->parent;
        if (! empty($parent_id) && $parent_id == 145){
        $grocery_cats .= '<li><a class="curr-cat" href="https://foodin.io/product-category/groceries/' . $cat_slug . '">' . $product_category->name . '</a></li>';
			foreach ( $product_categories as $product_category ){
				$subcat_id = $product_category->term_id;
				$subparent_id = $product_category->parent;
				$subcat_slug = $product_category->slug;
				
				if ($subparent_id == $cat_id){
					$grocery_cats .= '<li><a class="curr-cat subcat" href="https://foodin.io/product-category/groceries/' . $cat_slug . '/'. $subcat_slug . '">' . $product_category->name . '</a></li>';
				}
			}
		}
		if (! empty($parent_id) && $parent_id == 333){
			$recipe_cats .= '<li><a class="curr-cat" href="https://foodin.io/product-category/recipes/' . $cat_slug . '">' . $product_category->name . '</a></li>';
			foreach ( $product_categories as $product_category ){
				$subcat_id = $product_category->term_id;
				$subparent_id = $product_category->parent;
				$subcat_slug = $product_category->slug;

				if ($subparent_id == $cat_id){
					$recipe_cats .= '<li><a class="curr-cat subcat" href="https://foodin.io/product-category/recipes/' . $cat_slug . '/'. $subcat_slug . '">' . $product_category->name . '</a></li>';
				}
			}
		}
		if (! empty($parent_id) && $parent_id == 107){
			$plan_cats .= '<li><a class="curr-cat" href="https://foodin.io/product-category/plans/' . $cat_slug . '">' . $product_category->name . '</a></li>';
			foreach ( $product_categories as $product_category ){
				$subcat_id = $product_category->term_id;
				$subparent_id = $product_category->parent;
				$subcat_slug = $product_category->slug;

				if ($subparent_id == $cat_id){
					$plan_cats .= '<li><a class="curr-cat subcat" href="https://foodin.io/product-category/plans/' . $cat_slug . '/'. $subcat_slug . '">' . $product_category->name . '</a></li>';
				}
			}
		}
    }
 
 ?>

<div class="categories_cont" id="grocery_cats">
	<h3 class="widget-title h-title mb-30">Categories</h3>
	<div class="categories-wrapper">
		<ul class="wcpv-vendor-current-region-categories curr-cats">
			<?php echo $grocery_cats; ?>
		</ul>
	</div>
</div>

<div class="categories_cont" id="recipe_cats">
	<h3 class="widget-title h-title mb-30">Categories</h3>
	<div class="categories-wrapper">
		<ul class="wcpv-vendor-current-region-categories curr-cats">
			<?php echo $recipe_cats; ?>
		</ul>
	</div>
</div>

<div class="categories_cont" id="plan_cats">
	<h3 class="widget-title h-title mb-30">Categories</h3>
	<div class="categories-wrapper">
		<ul class="wcpv-vendor-current-region-categories curr-cats">
			<?php echo $plan_cats; ?>
		</ul>
	</div>
</div>


<script>
	
	if (window.location.href.indexOf("plans") > -1){
		document.getElementById("grocery_cats").style.display = "none";
		document.getElementById("recipe_cats").style.display = "none";
		document.getElementById("plan_cats").style.display = "block";
		document.getElementById("searchform").action = "?product_cat=plans";
	} else if (window.location.href.indexOf("recipes") > -1){
		document.getElementById("grocery_cats").style.display = "none";
		document.getElementById("plan_cats").style.display = "none";
		document.getElementById("recipe_cats").style.display = "block";
		document.getElementById("searchform").action = "?product_cat=recipes";
	} else if (window.location.href.indexOf("groceries") > -1){
		document.getElementById("recipe_cats").style.display = "none";
		document.getElementById("plan_cats").style.display = "none";
		document.getElementById("grocery_cats").style.display = "block";
		document.getElementById("searchform").action = "?product_cat=groceries";
	} else {
		document.getElementById("recipe_cats").style.display = "none";
		document.getElementById("plan_cats").style.display = "none";
		document.getElementById("grocery_cats").style.display = "block";
	}
	
// Get the container element
	var btnContainer = document.getElementsByClassName("categories_cont");
	var windowLocationHref = window.location.href.split('/');
	for(a=0;a<btnContainer.length;a++){
		var categoriesWrapper = btnContainer[a].getElementsByClassName("categories-wrapper")[0];
		var currCats = categoriesWrapper.getElementsByClassName("wcpv-vendor-current-region-categories curr-cats")[0];
		var catList = currCats.getElementsByTagName("li");
		for(i=0;i<catList.length;i++){
			var linkarr = catList[i].getElementsByTagName("a")[0].href.split('/');
			var link = linkarr[linkarr.length-1];
			if (windowLocationHref.includes(link)){
				catList[i].getElementsByTagName("a")[0].className += " active";
			}
		}
	}

</script>
