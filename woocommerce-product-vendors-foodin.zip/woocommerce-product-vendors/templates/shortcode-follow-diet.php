<?php
/**
 * Foodin Follow Diet
 *
 * @version 1.0.0.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>

<?php
if (is_user_logged_in()){
	$user_id = get_current_user_id();
	if ($_POST['assigned_diet']){
		update_user_meta( $user_id, 'assigned_diet', $_POST['assigned_diet'] );
		if($_POST['assigned_diet'] == 'none'){
			update_user_meta( $user_id, 'custom_diet', 'Yes' );
		} else {
			update_user_meta( $user_id, 'custom_diet', 'No' );
		}
	}
	$id = $atts['id'];
	$product =  wc_get_product($id);
	$name = $product->get_name();
	$user_diet_id =  esc_attr( get_the_author_meta( 'assigned_diet', $user_id ));
	$homeurl = get_home_url();
	$feedurl = $homeurl. '/profile/foodin-feed';

	if ($user_diet_id == $id) {
		echo '<form method="post" action="">';
		echo '<button onclick="changeButton(this)" class="button btn-white" name="assigned_diet" type="submit" value="none">Unfollow</button>';
		echo '</form>';
	} else {
		echo '<form method="post" action="">';
		echo '<button onclick="changeButton(this)" class="button btn-primary" name="assigned_diet" type="submit" value="'.$id.'">Follow</button>';
		echo '</form>';
	};
	
	if($_POST['assigned_diet']=='none'){
		echo '<p style="margin-top:10px;">You aren&#39;t following '. $name. ' anymore. Sorry to see you go.</p>';
	} elseif ($_POST['assigned_diet'] == $id) {
		echo '<p style="margin-top:10px;">You are now following '. $name. ', check your <a class="blue" href="'.$feedurl.'"> Feed</a> and be up to date!</p>';
	}
?><script>
	function changeButton(item){
		if(item.value == "none"){
			item.innerText = 'Follow';
			item.classList.remove("btn-white");
			item.classList.add("btn-primary");
			item.value = 'none';
		} else {
			item.innerText = 'Unfollow';
			item.classList.remove("btn-primary");
			item.classList.add("btn-white");
			item.value = <?php echo $id?>;
		}
	}
</script><?php
	
}
?>